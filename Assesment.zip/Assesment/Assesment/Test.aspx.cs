﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.IO;
using  System.Text.RegularExpressions;
namespace Assesment
{
    public partial class WebForm1 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnImport_Click(object sender, EventArgs e)
        {

            // Get the java file
            string txtPath = Server.MapPath("~/Files/") + Path.GetFileName(FileUpload1.PostedFile.FileName);
            FileUpload1.SaveAs(txtPath);

          //  count the Lines of Code and dispay on the label
            int txtData = File.ReadLines(txtPath).Count(str => !str.Contains("/*") & !str.Contains("*/") & !str.Contains("*") & !str.Contains("//"));
            lblcount.Text = txtData.ToString();

        
            
        }
    }
}